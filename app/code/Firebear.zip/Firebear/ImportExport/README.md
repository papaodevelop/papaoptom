Magento 2 - Improved Import / Export extension by FireBear Studio  

Extension manual - https://firebearstudio.com/blog/improved-import-magento-2-extension-manual.html

Sample files - https://github.com/firebearstudio/magento2-import-export-sample-files

Support - https://firebearstudio.com/contacts 
