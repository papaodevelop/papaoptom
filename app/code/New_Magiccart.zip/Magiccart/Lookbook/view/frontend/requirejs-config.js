var config = {
	paths: {
		'magiccart/easypin'		: 'Magiccart_Lookbook/js/jquery.easypin.min',
	},
	shim: {
		'magiccart/easypin': {
			deps: ['jquery', 'magiccart/easing']
		},
	}

};
