<?php
/**
 * Magiccart 
 * @category 	Magiccart 
 * @copyright 	Copyright (c) 2014 Magiccart (http://www.magiccart.net/) 
 * @license 	http://www.magiccart.net/license-agreement.html
 * @Author: DOng NGuyen<nguyen@dvn.com>
 * @@Create Date: 2017-08-26 15:31:37
 * @@Modify Date: 2017-08-30 23:51:51
 * @@Function:
 */

namespace Magiccart\Alothemes\Block\Widget;
 
class Facebook extends Socialstream
{

}
