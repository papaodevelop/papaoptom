<?php
/**
 * Magiccart 
 * @category 	Magiccart 
 * @copyright 	Copyright (c) 2014 Magiccart (http://www.magiccart.net/) 
 * @license 	http://www.magiccart.net/license-agreement.html
 * @Author: Magiccart<team.magiccart@gmail.com>
 * @@Create Date: 2017-08-31 00:01:29
 * @@Modify Date: 2017-08-31 00:24:43
 * @@Function:
 */

namespace Magiccart\Alothemes\Block;

use Magiccart\Alothemes\Block\Widget\Socialstream;
 
class Social extends Socialstream
{   

}
