<?php

/**
 * @Author: nguyen
 * @Date:   2020-05-13 22:12:09
 * @Last Modified by:   nguyen
 * @Last Modified time: 2020-05-13 22:14:42
 */

namespace Magiccart\Alothemes\Block;
 
class Newsletter  extends \Magento\Newsletter\Block\Subscribe
{   

}
