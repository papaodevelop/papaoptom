# Magento 2 Extention Magicslider
**Magicslider extension** allows you show a slider of banner to help you highlight your promotion, hot news or any target information. Moreover, this extension also make your website more attractive and looks beautiful.

## Look in frontend

![widget-img](https://github.com/magiccart/magento2-magicslider/blob/master/media/frontend_magicslider.jpg)

## How to install Magicslider Extension
### ✓ Install Magiccart Magicslider via composer (recommend)
Run the following command in Magento 2 root folder:

`composer require magiccart/magicslider`

`php bin/magento setup:upgrade`

`php bin/magento setup:static-content:deploy -f`

## Highlight Features
- Add a banner slider flexibly to any page on live store, such as homepage, category page, product page, CMS page…
- Add Unlimited banners to slide out on page as flow of image
- Ability to create banner sliders with any content: images, videos, URL links,...
- Ability to re-size (width, height), change its text color/size, set up images loading speed, animation effect..
- Enable/ Disable sliders at anytime
- Upload images or videos
- Allow to upload particular image in mobile


## Magiccart Magicslider user guide
[USE GUIDE](https://docs.alothemes.com/m2/theme/gecko/#sub65)

**Free Extensions List**

* [Magento 2 Recent Sales Notification](https://magepow.com/magento-2-recent-sales-notification.html)

* [Magento Categories Extension](https://magepow.com/magento-categories-extension.html)

* [Magento Sticky Cart](https://magepow.com/magento-sticky-cart.html)

* [Magento Ajax Contact](https://magepow.com/magento-ajax-contact-form.html)

* [Magento Lazy Load](https://magepow.com/magento-lazy-load.html)


**Premium Extensions List**

* [Magento Speed Optimizer](https://magepow.com/magento-speed-optimizer.html)

* [Magento 2 Mutil Translate](https://magepow.com/magento-multi-translate.html)

* [Magento 2 Instagram Integration](https://magepow.com/magento-2-instagram.html)

* [Lookbook Pin Products](https://magepow.com/lookbook-pin-products.html)

* [Magento Product Slider](https://magepow.com/magento-product-slider.html)

* [Magento Product Banner](https://magepow.com/magento-banner-slider.html)


**Featured Magento Themes**

* [Expert Multipurpose responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/expert-premium-responsive-magento-2-and-1-support-rtl-magento-2-/21667789)

* [Gecko Premium responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/gecko-responsive-magento-2-theme-rtl-supported/24677410)

* [Milano Fashion responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/milano-fashion-responsive-magento-1-2-theme/12141971)

* [Electro responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/electro-responsive-magento-1-2-theme/17042067)

* [Pizzaro food responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/pizzaro-food-responsive-magento-1-2-theme/19438157)

* [Biolife organic responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/biolife-organic-food-magento-2-theme-rtl-supported/25712510)

* [Market responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/market-responsive-magento-2-theme/22997928)

* [Kuteshop responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/kuteshop-multipurpose-responsive-magento-1-2-theme/12985435)


**Featured Magento Services**

* [PSD to Magento 2 Theme Conversion](https://magepow.com/psd-to-magento-theme-conversion.html)

* [Magento Speed Optimization Service](https://magepow.com/magento-speed-optimization-service.html)

* [Magento Security Patch Installation](https://magepow.com/magento-security-patch-installation.html)

* [Magento Website Maintenance Service](https://magepow.com/website-maintenance-service.html)

* [Magento Professional Installation Service](https://magepow.com/professional-installation-service.html)

* [Magento Upgrade Service](https://magepow.com/magento-upgrade-service.html)

* [Customization Service](https://magepow.com/customization-service.html)

* [Hire Magento Developer](https://magepow.com/hire-magento-developer.html)

[![Latest Stable Version](https://poser.pugx.org/magiccart/magicslider/v/stable)](https://packagist.org/packages/magiccart/magicslider)
[![Total Downloads](https://poser.pugx.org/magiccart/magicslider/downloads)](https://packagist.org/packages/magiccart/magicslider)
