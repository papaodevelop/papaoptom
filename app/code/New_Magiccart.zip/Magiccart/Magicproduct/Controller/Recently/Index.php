<?php
/**
 * Magiccart 
 * @category    Magiccart 
 * @copyright   Copyright (c) 2014 Magiccart (http://www.magiccart.net/) 
 * @license     http://www.magiccart.net/license-agreement.html
 * @Author: DOng NGuyen<nguyen@dvn.com>
 * @@Create Date: 2018-02-01 15:15:37
 * @@Modify Date: 2018-03-08 14:15:20
 * @@Function:
 */

namespace Magiccart\Magicproduct\Controller\Recently;

class Index extends \Magiccart\Magicproduct\Controller\Bestseller\Index
{
    
}
