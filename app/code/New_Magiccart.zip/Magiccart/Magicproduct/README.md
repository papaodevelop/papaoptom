# Magento 2 Extention Magicproduct
**Magicproduct Magento extension** (Product Slider Extension) is an important extension that helps you show a list of products as a slider on any live store pages such as homepage, category page, product page, checkout page…By using this extension, you don’t have to create and add a lot of bestsellers, onsale products, featured products,... manually, your live store still attracts more customers. Magento Product Slider will help customers see the brief of product information, rate and share them, add them to wishlist, cart…quickly. If you are looking for an extension to highlight a group of products and improve customer experience, Magento Product Slider is one of the must-have items.

## Highlight Features
- Easy to Disable/Enable the Slider
- Display Best Sellers, OnSale Products, Featured products, Newest products, Recently viewed products, Random Products or even a group of products as you want
- Easy and quick to insert products slider on page/ block by using widget options
- Place Slider any pages in your store
- Responsive sliders
- Set up the number of products and the row displayed for each slider
- Slider effects included
- Allow pick up products for sliders from whole store/ many categories/ one category
- Special Sliders with countdown timer


### ✓ Install Magiccart Magicproduct via composer (recommend)
Run the following command in Magento 2 root folder:

`composer require magiccart/magicproduct`

`php bin/magento setup:upgrade`

`php bin/magento setup:static-content:deploy -f`

## Magiccart Magicproduct user guide
[USE GUIDE](https://docs.alothemes.com/m2/extension/productslider/)



**Free Extensions List**

* [Magento 2 Recent Sales Notification](https://magepow.com/magento-2-recent-sales-notification.html)

* [Magento Categories Extension](https://magepow.com/magento-categories-extension.html)

* [Magento Sticky Cart](https://magepow.com/magento-sticky-cart.html)

* [Magento Ajax Contact](https://magepow.com/magento-ajax-contact-form.html)

* [Magento Lazy Load](https://magepow.com/magento-lazy-load.html)


**Premium Extensions List**

* [Magento Speed Optimizer](https://magepow.com/magento-speed-optimizer.html)

* [Magento 2 Mutil Translate](https://magepow.com/magento-multi-translate.html)

* [Magento 2 Instagram Integration](https://magepow.com/magento-2-instagram.html)

* [Lookbook Pin Products](https://magepow.com/lookbook-pin-products.html)

* [Magento Product Slider](https://magepow.com/magento-product-slider.html)

* [Magento Product Banner](https://magepow.com/magento-banner-slider.html)


**Featured Magento Themes**

* [Expert Multipurpose responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/expert-premium-responsive-magento-2-and-1-support-rtl-magento-2-/21667789)

* [Gecko Premium responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/gecko-responsive-magento-2-theme-rtl-supported/24677410)

* [Milano Fashion responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/milano-fashion-responsive-magento-1-2-theme/12141971)

* [Electro responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/electro-responsive-magento-1-2-theme/17042067)

* [Pizzaro food responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/pizzaro-food-responsive-magento-1-2-theme/19438157)

* [Biolife organic responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/biolife-organic-food-magento-2-theme-rtl-supported/25712510)

* [Market responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/market-responsive-magento-2-theme/22997928)

* [Kuteshop responsive Magento 2 Theme](https://1.envato.market/c/1314680/275988/4415?u=https://themeforest.net/item/kuteshop-multipurpose-responsive-magento-1-2-theme/12985435)


**Featured Magento Services**

* [PSD to Magento 2 Theme Conversion](https://magepow.com/psd-to-magento-theme-conversion.html)

* [Magento Speed Optimization Service](https://magepow.com/magento-speed-optimization-service.html)

* [Magento Security Patch Installation](https://magepow.com/magento-security-patch-installation.html)

* [Magento Website Maintenance Service](https://magepow.com/website-maintenance-service.html)

* [Magento Professional Installation Service](https://magepow.com/professional-installation-service.html)

* [Magento Upgrade Service](https://magepow.com/magento-upgrade-service.html)

* [Customization Service](https://magepow.com/customization-service.html)

* [Hire Magento Developer](https://magepow.com/hire-magento-developer.html)

[![Latest Stable Version](https://poser.pugx.org/magiccart/magicproduct/v/stable)](https://packagist.org/packages/magiccart/magicproduct)
[![Total Downloads](https://poser.pugx.org/magiccart/magicproduct/downloads)](https://packagist.org/packages/magiccart/magicproduct)
